﻿using OrderProcessing.Domains;
using System;
using System.Collections.Generic;
using System.Text;

namespace OrderProcessing
{
    public interface IPaymentService
    {
        bool ProcessPayment(PaymentType paymentType);
    }
}
