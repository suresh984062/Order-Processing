﻿using AutoFixture;
using OrderProcessing.Domains;
using System;
using System.Collections.Generic;
using System.Text;

namespace OrderProcessing.ObjectMother
{
    public static class ObjectPackagingSlip
    {
        public static PackagingSlip GetPackagingSlip()
        {
            return new Fixture().Create<PackagingSlip>();
        }

        public static RealPackagingSlip GetRoyaltyPackagingSlip()
        {
            return new Fixture().Create<RealPackagingSlip>();
        }
    }
}
