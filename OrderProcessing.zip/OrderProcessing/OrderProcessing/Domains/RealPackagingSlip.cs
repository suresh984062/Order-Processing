﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OrderProcessing.Domains
{
    public class RealPackagingSlip
    {
        public string RealCompanyName { get; set; }
        public string RealCompanyAddress { get; set; }
    }
}
